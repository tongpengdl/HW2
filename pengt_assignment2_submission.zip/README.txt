In this assignment, I created 3 packages - com.cmu.m_calculator, model, and util respectively.

com.cmu.m_calculator package is responsible for UI interaction
model package stores database as an object which stores user inputs.
util package is like a tool box which contains database connector and all methods for mortgage calculation.

In MainActivity, all user inputs are get and used to create an object. Then store this object in SQLite databse using saveUserInputs() method. Next, use this object as an arguement to calculate Total Monthly Payment, Total of 360 payments and Payoff date. Finally pass all the results to the ResultActivity class for display.