package model;



// this class is used to store all user inputs
public class DBentity {
    private int purchasePrice;
    private double downPayment;
    private int mortGageTerm;
    private double interestRate;
    private double propertyTax;
    private double propertyInsurance;
    private double pmi;
    private int zipCode;
    private String month;
    private String year;

    public DBentity(int purchasePrice, double downPayment, int mortGageTerm,
                double interestRate, double propertyTax, double propertyInsurance,
                double pmi, int zipCode, String month, String year) {
        super();
        this.purchasePrice = purchasePrice;
        this.downPayment = downPayment;
        this.mortGageTerm = mortGageTerm;
        this.interestRate = interestRate;
        this.propertyTax = propertyTax;
        this.propertyInsurance = propertyInsurance;
        this.pmi = pmi;
        this.zipCode = zipCode;
        this.month = month;
        this.year = year;
    }

    public int getPurchasePrice() {
        return purchasePrice;
    }
    public double getDownPayment() {
        return downPayment;
    }
    public int getMortGageTerm() {
        return mortGageTerm;
    }
    public double getInterestRate() {
        return interestRate;
    }
    public double getPropertyTax() {
        return propertyTax;
    }
    public double getPropertyInsurance() {
        return propertyInsurance;
    }
    public double getPmi() {
        return pmi;
    }
    public int getZipCode() {
        return zipCode;
    }
    public String getMonth() {
        return month;
    }
    public String getYear() {
        return year;
    }
    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }
    public void setDownPayment(double downPayment) {
        this.downPayment = downPayment;
    }
    public void setMortGageTerm(int mortGageTerm) {
        this.mortGageTerm = mortGageTerm;
    }
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
    public void setPropertyTax(double propertyTax) {
        this.propertyTax = propertyTax;
    }
    public void setPropertyInsurance(double propertyInsurance) {
        this.propertyInsurance = propertyInsurance;
    }
    public void setPmi(double pmi) {
        this.pmi = pmi;
    }
    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }
    public void setMonth(String month) {
        this.month = month;
    }
    public void setYear(String year) {
        this.year = year;
    }


}
