package com.cmu.m_calculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;


public class ResultActivity extends Activity {

    private TextView totalMonthPaymentText;
    private TextView totalOfPaymentForMortgageTermText;
    private TextView dateText;
    private double totalMonthPayment;
    private double totalOfPaymentForMortgageTerm;
    private String date;
    private Button returnButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        //get reference
        totalMonthPaymentText = (TextView) findViewById(R.id.totalMonthPayment_output);
        totalOfPaymentForMortgageTermText = (TextView) findViewById(R.id.totalOfPaymentForMortgageTerm_output);
        dateText = (TextView) findViewById(R.id.date_output);

        //get results
        Intent intent = getIntent();
        totalMonthPayment = intent.getDoubleExtra("totalMonthPayment", 0.0);
        totalOfPaymentForMortgageTerm = intent.getDoubleExtra("totalOfPaymentForMortgageTerm",0.0);
        date = intent.getStringExtra("PayoffDate");

        //display results
        totalMonthPaymentText.setText("$"+totalMonthPayment);
        totalOfPaymentForMortgageTermText.setText("$"+totalOfPaymentForMortgageTerm);
        dateText.setText(date);

        returnButton = (Button) findViewById(R.id.Return);
        returnButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent Return = new Intent(ResultActivity.this, MainActivity.class);

                startActivity(Return);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_result, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
