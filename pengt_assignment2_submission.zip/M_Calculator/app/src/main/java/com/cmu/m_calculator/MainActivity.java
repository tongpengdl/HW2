package com.cmu.m_calculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.view.View.OnClickListener;
import android.view.View;

import model.DBentity;
import util.DatabaseConnector;
import util.MortgageCalculator;


public class MainActivity extends Activity {

    private long rowID;

    private DBentity db;
    private DatabaseConnector databaseConnector;

    private EditText purchasePrice_input;
    private EditText downPayment_input;
    private EditText mortGageTerm_input;
    private EditText interestRate_input;
    private EditText propertyTax_input;
    private EditText propertyInsurance_input;
    private EditText PMI_input;
    private EditText zipCode_input;
    private Spinner monthSpinner;
    private Spinner yearSpinner;
    private Button calculator;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get reference
        purchasePrice_input = (EditText) findViewById(R.id.purchasePrice_input);
        downPayment_input = (EditText) findViewById(R.id.downPayment_input);
        mortGageTerm_input = (EditText) findViewById(R.id.mortGageTerm_input);
        interestRate_input = (EditText) findViewById(R.id.interestRate_input);
        propertyTax_input = (EditText) findViewById(R.id.propertyTax_input);
        propertyInsurance_input = (EditText) findViewById(R.id.propertyInsurance_input);
        PMI_input = (EditText) findViewById(R.id.PMI_input);
        zipCode_input = (EditText) findViewById(R.id.zipCode_input);
        monthSpinner = (Spinner) findViewById(R.id.monthSpinner);
        yearSpinner = (Spinner) findViewById(R.id.yearSpinner);
        calculator = (Button) findViewById(R.id.Return);

        Bundle extras = getIntent().getExtras();
        //get row id
        if (extras != null) rowID = extras.getLong("row_id");

        //set initial values
        if(savedInstanceState == null){
            purchasePrice_input.setText("300000");
            downPayment_input.setText("20");
            mortGageTerm_input.setText("30");
            interestRate_input.setText("4.5");
            propertyTax_input.setText("3000");
            propertyInsurance_input.setText("1500");
            PMI_input.setText("0.52");
            zipCode_input.setText("94041");
            monthSpinner.setSelection(4);
            yearSpinner.setSelection(4);
        }

        addListenerOnButton();
    }

    protected void addListenerOnButton() {

        calculator = (Button) findViewById(R.id.calculator);

        calculator.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {

                db = new DBentity(  // create an object to store all user inputs
                        Integer.parseInt(purchasePrice_input.getText().toString()),
                        Double.parseDouble(downPayment_input.getText().toString()),
                        Integer.parseInt(mortGageTerm_input.getText().toString()),
                        Double.parseDouble(interestRate_input.getText().toString()),
                        Double.parseDouble(propertyTax_input.getText().toString()),
                        Double.parseDouble(propertyInsurance_input.getText().toString()),
                        Double.parseDouble(PMI_input.getText().toString()),
                        Integer.parseInt(zipCode_input.getText().toString()),
                        monthSpinner.getSelectedItem().toString(),
                        yearSpinner.getSelectedItem().toString()
                );

                saveUserInputs(); //store the object in SQLite database



                MortgageCalculator m = new MortgageCalculator();

                /*
                 * calculate results using the object created
                 */
                double totalMonthPayment = m.calculateMonthlyPayment(db.getPurchasePrice(), db.getDownPayment(), db.getMortGageTerm(),
                        db.getInterestRate(), db.getPropertyTax(), db.getPropertyInsurance());
                double totalOfPaymentForMortgageTerm = m.calculateTotalPayment(totalMonthPayment, db.getMortGageTerm());
                String PayoffDate = m.calculatePayoffDate(db.getYear(), db.getMonth(), db.getMortGageTerm());

                Intent result = new Intent(MainActivity.this, ResultActivity.class);
                result.putExtra("totalMonthPayment", totalMonthPayment);
                result.putExtra("totalOfPaymentForMortgageTerm", totalOfPaymentForMortgageTerm);
                result.putExtra("PayoffDate", PayoffDate);
                startActivity(result);
            }

        });

    }

    public void saveUserInputs(){
        databaseConnector = new DatabaseConnector(this);

        if(getIntent().getExtras()==null){
            databaseConnector.insertUserInputs(
                db.getPurchasePrice(),
                db.getDownPayment(),
                db.getMortGageTerm(),
                db.getInterestRate(),
                db.getPropertyTax(),
                db.getPropertyInsurance(),
                db.getPmi(),
                db.getZipCode(),
                db.getMonth(),
                db.getYear()
            );
        }else{
            databaseConnector.updateUserInputs(
                    db.getPurchasePrice(),
                    db.getDownPayment(),
                    db.getMortGageTerm(),
                    db.getInterestRate(),
                    db.getPropertyTax(),
                    db.getPropertyInsurance(),
                    db.getPmi(),
                    db.getZipCode(),
                    db.getMonth(),
                    db.getYear(),
                    rowID
            );
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
