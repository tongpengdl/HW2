package util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

import model.DBentity;

public class DatabaseConnector
{
    // database name
    private static final String DATABASE_NAME = "MyDatabase";
    private SQLiteDatabase database; // database object
    private DatabaseOpenHelper databaseOpenHelper; // database helper

    // public constructor for DatabaseConnector
    public DatabaseConnector(Context context)
    {
        // create a new DatabaseOpenHelper
        databaseOpenHelper =
                new DatabaseOpenHelper(context, DATABASE_NAME, null, 1);
    } // end DatabaseConnector constructor

    // open the database connection
    public void open() throws SQLException
    {
        // create or open a database for reading/writing
        database = databaseOpenHelper.getWritableDatabase();
    } // end method open

    // close the database connection
    public void close()
    {
        if (database != null)
            database.close(); // close the database connection
    } // end method close

    // inserts a new contact in the database
    public void insertUserInputs(int purchasePrice, double downPayment, int mortGageTerm,
                              double interestRate, double propertyTax, double propertyInsurance,
                              double pmi, int zipCode, String month, String year)
    {
        ContentValues newInputs = new ContentValues();
        newInputs.put("purchasePrice", purchasePrice);
        newInputs.put("downPayment", downPayment);
        newInputs.put("mortGageTerm", mortGageTerm);
        newInputs.put("interestRate", interestRate);
        newInputs.put("propertyTax", propertyTax);
        newInputs.put("propertyInsurance", propertyInsurance);
        newInputs.put("pmi", pmi);
        newInputs.put("zipCode", zipCode);
        newInputs.put("month", month);
        newInputs.put("year", year);

        open(); // open the database
        database.insert("UserInputs", null, newInputs);
        close(); // close the database
    } // end method insertContact

    // inserts a new contact in the database
    public void updateUserInputs(int purchasePrice, double downPayment, int mortGageTerm,
                                 double interestRate, double propertyTax, double propertyInsurance,
                                 double pmi, int zipCode, String month, String year, Long id)
    {
        ContentValues editUserInputs = new ContentValues();
        editUserInputs.put("purchasePrice", purchasePrice);
        editUserInputs.put("downPayment", downPayment);
        editUserInputs.put("mortGageTerm", mortGageTerm);
        editUserInputs.put("interestRate", interestRate);
        editUserInputs.put("propertyTax", propertyTax);
        editUserInputs.put("propertyInsurance", propertyInsurance);
        editUserInputs.put("pmi", pmi);
        editUserInputs.put("zipCode", zipCode);
        editUserInputs.put("month", month);
        editUserInputs.put("year", year);

        open(); // open the database
        database.update("UserInputs", editUserInputs, "_id=" + id, null);
        close(); // close the database
    } // end method updateContact

    // return a Cursor with all contact information in the database
    public Cursor getAllUserInputs()
    {
        return database.query("UserInputs", new String[] {"_id"},
                null, null, null, null, "id");
    } // end method getAllContacts


    public DBentity getOneUserInput(long id){
        open();
        Cursor cursor = database.query(
                "UserInputs", null, "_id=" + id, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        DBentity dBentity = new DBentity(cursor.getInt(0),cursor.getDouble(1),cursor.getInt(2),
                cursor.getDouble(3), cursor.getDouble(4), cursor.getDouble(5), cursor.getDouble(6),
                cursor.getInt(7), cursor.getString(8), cursor.getString(9));
        System.out.println("Purchase price: " + dBentity.getPurchasePrice());
        System.out.println("Down payment: "+ dBentity.getDownPayment());
        close();
        return dBentity;

    }
    // get a Cursor containing all information about the contact specified
    // by the given id
    public Cursor getOneUserInputs(long id)
    {
        return database.query(
                "UserInputs", null, "_id=" + id, null, null, null, null);
    } // end method getOnContact

    // delete the contact specified by the given String name
    public void deleteUserInputs(long id)
    {
        open(); // open the database
        database.delete("UserInputs", "_id=" + id, null);
        close(); // close the database
    } // end method deleteContact

    private class DatabaseOpenHelper extends SQLiteOpenHelper
    {
        // public constructor
        public DatabaseOpenHelper(Context context, String name,
                                  CursorFactory factory, int version)
        {
            super(context, name, factory, version);
        } // end DatabaseOpenHelper constructor

        // creates the contacts table when the database is created
        @Override
        public void onCreate(SQLiteDatabase db)
        {
            // query to create a new table named contacts
            String createQuery = "CREATE TABLE UserInputs" +
                    "(_id integer primary key autoincrement," +
                    "purchasePrice INT, downPayment NUM, mortGageTerm INT, interestRate NUM," +
                    "propertyTax NUM, propertyInsurance NUM, pmi NUM, zipCode INT, month TEXT, year TEXT);";

            db.execSQL(createQuery); // execute the query
        } // end method onCreate

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion,
                              int newVersion)
        {
        } // end method onUpgrade
    } // end class DatabaseOpenHelper
} // end class DatabaseConnector

