package util;

import java.util.ArrayList;

public class MortgageCalculator {

    public double calculateMonthlyPayment(
            int loanAmount, double downPayment, int termInYears, double interestRate, double propertyTax, double propertyInsurance) {

        interestRate /= 100.0;

        double monthlyRate = interestRate / 12.0;

        int termInMonths = termInYears * 12;

        double monthlyPayment =
                (loanAmount*monthlyRate*(1-downPayment/100)) /
                        (1-Math.pow(1+monthlyRate, -termInMonths));

        monthlyPayment += propertyTax/12 + propertyInsurance/12;

        return monthlyPayment;
    }

    public double calculateTotalPayment(double monthlyPayment, int termInYears){
        return monthlyPayment*termInYears*12;
    }

    public String calculatePayoffDate(String year, String month, int termInYears){
        StringBuffer date = new StringBuffer();
        ArrayList month_array = new ArrayList<String>();
        month_array.add("Jan");
        month_array.add("Feb");
        month_array.add("Mar");
        month_array.add("Apr");
        month_array.add("May");
        month_array.add("Jun");
        month_array.add("Jul");
        month_array.add("Aug");
        month_array.add("Sep");
        month_array.add("Oct");
        month_array.add("Nov");
        month_array.add("Dec");
        String Month;
        int Year = Integer.parseInt(year);
        Year += termInYears;

        if(month.equals("Jan")){
            Month = "Dec";
            Year --;
        }else{
            int index = month_array.lastIndexOf(month);
            Month = (String)month_array.get(index-1);
        }

        date.append(Month).append(",").append(Year);
        return date.toString();

    }

}
